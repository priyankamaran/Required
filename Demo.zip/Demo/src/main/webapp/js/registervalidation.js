function validate()
{
	
}
function validate1()
{
	var s = document.getElementById('pwd').value;
	if(s.length<8)
		{
		alert("Password should be atleast 8 characters ");
		}
}
function validate2()
{
	var s = document.getElementById('pwd').value;
	var s1 = document.getElementById('cwd').value;
	if(s.compareTo(s1)!=0)
		{
		alert("Password Mismatch ");
		}
	
}
function validate3()
{
	var n = document.getElementById('mnum').value;
	if(isNaN(n)||n.length<10||n.length>10)
		{
		alert("Invalid Mobile Number");
		}
}
function validate4()
{
	//var n = document.getElementById('mnum').value;
	if(isNaN(n))
		{
		
		}
	else
		alert("Invalid UserName");
		
}

function validate5()
{
	var n = document.getElementById('title').value;
	if(n.length==0)
		{
		alert("Fill Details");
		}
}
function validate6()
{
	var n = document.getElementById('quote').value;
	if(n.length==0)
		{
		alert("Fill Details");
		}
}
function validate7()
{
	var n = document.getElementById('contact').value;
	if(n.length==0)
		{
		alert("Fill Details");
		}
}