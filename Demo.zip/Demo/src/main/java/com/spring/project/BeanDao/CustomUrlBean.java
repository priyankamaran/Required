package com.spring.project.BeanDao;

public class CustomUrlBean {
	int customurl_id,cust_id;
	String url;
	String durl;
	public String getDurl() {
		return durl;
	}
	public void setDurl(String durl) {
		this.durl = durl;
	}
	public int getCustomurl_id() {
		return customurl_id;
	}
	public void setCustomurl_id(int customurl_id) {
		this.customurl_id = customurl_id;
	}
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

}
